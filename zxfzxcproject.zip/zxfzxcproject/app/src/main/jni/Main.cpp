#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include <GLES2/gl2.h>
#include <src/Chams.h>

#include "KittyMemory/MemoryPatch.h"
#include "Menu.h"

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"

// fancy struct for patches for kittyMemory
struct My_Patches {
    // let's assume we have patches for these functions for whatever game
    // like show in miniMap boolean function
    MemoryPatch GodMode, GodMode2, SliderExample;
    // etc...
} hexPatches;

bool chams, wireframe, glow, outline, rainbow228 = false;
bool setid = 0;


void (*SendChat)(void* _this, int);
void(*old_MultiPlayerChat_Update)(void *instance);

void MultiPlayerChat_Update(void *instance) {
    if (instance != NULL ) {
        if(setid == 0){

            ///SendChat(instance, );
            
              } else if (setid == 1) {
             SendChat(instance, 16);
           
              } else if (setid == 2) {
             SendChat(instance, 1);
           
              } else if (setid == 3) {
             SendChat(instance, 32);
             
                 } else if (setid == 4) {
             SendChat(instance, 34);
             
                 } else if (setid == 5) {
             SendChat(instance, 35);
             
                 } else if (setid == 6) {
             SendChat(instance, 22);
             
                 } else if (setid == 7) {
             SendChat(instance, 7);
             
                 } else if (setid == 8) {
             SendChat(instance, 3);
             
                 } else if (setid == 9) {
             SendChat(instance, 15);
             
                 } else if (setid == 10) {
             SendChat(instance, 28);
             
                 } else if (setid == 11) {
             SendChat(instance, 8);
             
                 } else if (setid == 12) {
             SendChat(instance, 18);
             
                 } else if (setid == 13) {
             SendChat(instance, 4);
             
                 } else if (setid == 14) {
             SendChat(instance, 26);
             
                 } else if (setid == 15) {
             SendChat(instance, 33);
             
                 } else if (setid == 16) {
             SendChat(instance, 21);
             
                 } else if (setid == 17) {
             SendChat(instance, 14);
             
                 } else if (setid == 18) {
             SendChat(instance, 24);
             
                 } else if (setid == 19) {
             SendChat(instance, 6);
             
                 } else if (setid == 20) {
             SendChat(instance, 5);
             
                 } else if (setid == 21) {
             SendChat(instance, 13);
             
                   } else if (setid == 22) {
             SendChat(instance, 20);
             
                   } else if (setid == 23) {
             SendChat(instance, 10);
             
                   } else if (setid == 24) {
             SendChat(instance, 30);
             
                   } else if (setid == 25) {
             SendChat(instance, 12);
             
                   } else if (setid == 26) {
             SendChat(instance, 31);
             
                   } else if (setid == 27) {
             SendChat(instance, 19);
             
                   } else if (setid == 28) {
             SendChat(instance, 9);
             
                   } else if (setid == 29) {
             SendChat(instance, 27);
             
                   } else if (setid == 30) {
             SendChat(instance, 23);
             
             
 } 
        old_MultiPlayerChat_Update(instance);
    }
    old_MultiPlayerChat_Update(instance);
}

void *hack_thread(void *) {
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName) && molvinit());
    do {
        sleep(1);
    } while (!isLibraryLoaded("libzxfzxc.so"));
    setShader("_BumpMap");
    LogShaders();
    Wallhack();

MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x6A7A28), (void *) MultiPlayerChat_Update,
                   (void **) &old_MultiPlayerChat_Update);//
            
    SendChat = (void(*)(void *, int))getAbsoluteAddress(targetLibName, 0x68A7AC);//0x68A7AC


/* HOOK("str", FunctionExample, old_FunctionExample);
    HOOK_LIB("libFileB.so", "0x123456", FunctionExample, old_FunctionExample);
    HOOK_NO_ORIG("0x123456", FunctionExample);
    HOOK_LIB_NO_ORIG("libFileC.so", "0x123456", FunctionExample);
    HOOKSYM("__SymbolNameExample", FunctionExample, old_FunctionExample);
    HOOKSYM_LIB("libFileB.so", "__SymbolNameExample", FunctionExample, old_FunctionExample);
    HOOKSYM_NO_ORIG("__SymbolNameExample", FunctionExample);
    HOOKSYM_LIB_NO_ORIG("libFileB.so", "__SymbolNameExample", FunctionExample);

    PATCHOFFSET("0x20D3A8", "00 00 A0 E3 1E FF 2F E1");
    PATCHOFFSET_LIB("libFileB.so", "0x20D3A8", "00 00 A0 E3 1E FF 2F E1"); 
    */

#endif

    return NULL;
}

extern "C" {

JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it
    MakeToast(env, context, OBFUSCATE("Creator zxfzxc"), Toast::LENGTH_LONG);

    const char *features[] = {
            OBFUSCATE("Collapse_Visual"),
            OBFUSCATE("CollapseAdd_CheckBox_Chams"),
            OBFUSCATE("CollapseAdd_CheckBox_Wireframe"),
            OBFUSCATE("CollapseAdd_CheckBox_Glow Chams"),
            OBFUSCATE("CollapseAdd_CheckBox_Outline Chams"),
            OBFUSCATE("CollapseAdd_CheckBox_Rainbow Chams"),
            OBFUSCATE("CollapseAdd_SeekBar_Line Width:_0_5"),
            OBFUSCATE("CollapseAdd_SeekBar_Set Red:_0_255"),
            OBFUSCATE("CollapseAdd_SeekBar_Set Green:_0_255"),
            OBFUSCATE("CollapseAdd_SeekBar_Set Blue:_0_255"),
            
            OBFUSCATE("Collapse_SetWeapon"),
            OBFUSCATE("CollapseAdd_Spinner_Set Weapon_OFF,A91, AK47,AWP,  Beretta, BrassKnuckles,ButterflyKnife,  C4,DesertEagle,  CX70, FAL,FiveSeven,Flashbang, FAMAS,  Glock, Huntsman, Karambit, Knife, M1014, M40,M4A1,  M98, MP5K,MP7,  MP9, P250, P90, PP2000, Spas12,Uzi,Tec9  "),//14"
            OBFUSCATE("CollapseAdd_ButtonLink_Telegram Channel Author_http://t.me/zxfzxcc"
      
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 1:
        chams = !chams;
        if (chams) {
        SetWallhack(true);
        } else {
        SetWallhack(false);
        }
        break;
        case 2:
        wireframe = !wireframe;
        if (wireframe) {
        SetWallhackW(true);
        } else {
        SetWallhackW(false);
        }
        break;
        case 3:
        glow = !glow;
        if (glow) {
        SetWallhackG(true);
        } else {
        SetWallhackG(false);
        }
        break;
        case 4:
        outline = !outline;
        if (outline) {
        SetWallhackO(true);
        } else {
        SetWallhackO(false);
        }
        break;
        case 5:
        rainbow228 = !rainbow228;
        if (rainbow228) {
        SetRainbow(true);
        } else {
        SetRainbow(false);
        }
        break;
        case 6:
        SetW(value);
        break;
		case 7:
        SetR(value);
        break;
        case 8:
        SetG(value);
        break;
        case 9:
        SetB(value);
        break;
        case 11:
        setid = value;
        break;
    }
}
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

/*
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}
 */
